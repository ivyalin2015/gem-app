// DEPRECATED
// import React from "react";
// import { Toolbar } from "react-native-ios-kit";

// export default function BottomToolbar({ navigation }) {
//   return (
//     <Toolbar
//       items={[
//         {
//           icon: "person-add",
//           onPress: this.runAction,
//         },
//         {
//           icon: "ios-location",
//           onPress: this.runAction,
//         },
//         {
//           icon: "bookmark",
//           onPress: this.runAction,
//         },
//         {
//           icon: "md-folder",
//           onPress: this.runAction,
//         },
//         {
//           icon: "person",
//           onPress: this.runAction,
//         },
//       ]}
//     />
//   );
// }
